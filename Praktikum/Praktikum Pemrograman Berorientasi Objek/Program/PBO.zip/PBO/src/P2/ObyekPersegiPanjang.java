/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P2;

/**
 *
 * @author FERGA
 */
public class ObyekPersegiPanjang {
    public static void main(String[] args){
        PersegiPanjang pp1 = new PersegiPanjang();
        pp1.setPanjangLebar(2,2);
        pp1.tampil();
    }
}
