/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package P2;

/**
 *
 * @author KomDas
 */
public class ObyekMahasiswa {
    public static void main(String[] args){
        Mahasiswa m1 = new Mahasiswa();
        m1.setMahasiswa("Ferdi Dirgantara", "Laki-Laki", "TI", 175410039, 21);
        m1.tampil();
    }
}
